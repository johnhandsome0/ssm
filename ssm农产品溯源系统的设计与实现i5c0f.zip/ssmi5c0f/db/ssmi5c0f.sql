-- MySQL dump 10.13  Distrib 5.7.31, for Linux (x86_64)
--
-- Host: localhost    Database: ssmi5c0f
-- ------------------------------------------------------
-- Server version	5.7.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ssmi5c0f`
--

/*!40000 DROP DATABASE IF EXISTS `ssmi5c0f`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ssmi5c0f` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `ssmi5c0f`;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(100) NOT NULL COMMENT '配置参数名称',
  `value` varchar(100) DEFAULT NULL COMMENT '配置参数值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='配置文件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES (1,'picture1','upload/picture1.jpg'),(2,'picture2','upload/picture2.jpg'),(3,'picture3','upload/picture3.jpg');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dingdanxinxi`
--

DROP TABLE IF EXISTS `dingdanxinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dingdanxinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `dingdanbianhao` varchar(200) DEFAULT NULL COMMENT '订单编号',
  `chanpinbianhao` varchar(200) DEFAULT NULL COMMENT '产品编号',
  `chanpinmingcheng` varchar(200) DEFAULT NULL COMMENT '产品名称',
  `guige` varchar(200) DEFAULT NULL COMMENT '规格',
  `shuliang` int(11) DEFAULT NULL COMMENT '数量',
  `danjia` int(11) DEFAULT NULL COMMENT '单价',
  `zongjia` double DEFAULT NULL COMMENT '总价',
  `goumaishijian` datetime DEFAULT NULL COMMENT '购买时间',
  `beizhu` varchar(200) DEFAULT NULL COMMENT '备注',
  `shangjiazhanghao` varchar(200) DEFAULT NULL COMMENT '商家账号',
  `shangjiaxingming` varchar(200) DEFAULT NULL COMMENT '商家姓名',
  `zhanghao` varchar(200) DEFAULT NULL COMMENT '账号',
  `xingming` varchar(200) DEFAULT NULL COMMENT '姓名',
  `sfsh` varchar(200) DEFAULT '待审核' COMMENT '是否审核',
  `shhf` longtext COMMENT '审核回复',
  `ispay` varchar(200) DEFAULT '未支付' COMMENT '是否支付',
  PRIMARY KEY (`id`),
  UNIQUE KEY `dingdanbianhao` (`dingdanbianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8 COMMENT='订单信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dingdanxinxi`
--

LOCK TABLES `dingdanxinxi` WRITE;
/*!40000 ALTER TABLE `dingdanxinxi` DISABLE KEYS */;
INSERT INTO `dingdanxinxi` VALUES (91,'2023-06-25 08:17:42','1111111111','产品编号1','产品名称1','规格1',1,1,1,'2023-06-25 16:17:42','备注1','商家账号1','商家姓名1','账号1','姓名1','是','','未支付'),(92,'2023-06-25 08:17:42','2222222222','产品编号2','产品名称2','规格2',2,2,2,'2023-06-25 16:17:42','备注2','商家账号2','商家姓名2','账号2','姓名2','是','','未支付'),(93,'2023-06-25 08:17:42','3333333333','产品编号3','产品名称3','规格3',3,3,3,'2023-06-25 16:17:42','备注3','商家账号3','商家姓名3','账号3','姓名3','是','','未支付'),(94,'2023-06-25 08:17:42','4444444444','产品编号4','产品名称4','规格4',4,4,4,'2023-06-25 16:17:42','备注4','商家账号4','商家姓名4','账号4','姓名4','是','','未支付'),(95,'2023-06-25 08:17:42','5555555555','产品编号5','产品名称5','规格5',5,5,5,'2023-06-25 16:17:42','备注5','商家账号5','商家姓名5','账号5','姓名5','是','','未支付'),(96,'2023-06-25 08:17:42','6666666666','产品编号6','产品名称6','规格6',6,6,6,'2023-06-25 16:17:42','备注6','商家账号6','商家姓名6','账号6','姓名6','是','','未支付'),(97,'2023-06-25 08:17:42','7777777777','产品编号7','产品名称7','规格7',7,7,7,'2023-06-25 16:17:42','备注7','商家账号7','商家姓名7','账号7','姓名7','是','','未支付'),(98,'2023-06-25 08:17:42','8888888888','产品编号8','产品名称8','规格8',8,8,8,'2023-06-25 16:17:42','备注8','商家账号8','商家姓名8','账号8','姓名8','是','','未支付');
/*!40000 ALTER TABLE `dingdanxinxi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jiagongxinxi`
--

DROP TABLE IF EXISTS `jiagongxinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jiagongxinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `chanpinbianhao` varchar(200) DEFAULT NULL COMMENT '产品编号',
  `chanpinmingcheng` varchar(200) DEFAULT NULL COMMENT '产品名称',
  `jiagongqiye` varchar(200) DEFAULT NULL COMMENT '加工企业',
  `jiagonggongxu` varchar(200) DEFAULT NULL COMMENT '加工工序',
  `jiagongshijian` date DEFAULT NULL COMMENT '加工时间',
  `jiagongzhongliang` varchar(200) DEFAULT NULL COMMENT '加工重量',
  `shangjiazhanghao` varchar(200) DEFAULT NULL COMMENT '商家账号',
  `shangjiaxingming` varchar(200) DEFAULT NULL COMMENT '商家姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8 COMMENT='加工信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jiagongxinxi`
--

LOCK TABLES `jiagongxinxi` WRITE;
/*!40000 ALTER TABLE `jiagongxinxi` DISABLE KEYS */;
INSERT INTO `jiagongxinxi` VALUES (61,'2023-06-25 08:17:41','产品编号1','产品名称1','加工企业1','加工工序1','2023-06-25','加工重量1','商家账号1','商家姓名1'),(62,'2023-06-25 08:17:41','产品编号2','产品名称2','加工企业2','加工工序2','2023-06-25','加工重量2','商家账号2','商家姓名2'),(63,'2023-06-25 08:17:41','产品编号3','产品名称3','加工企业3','加工工序3','2023-06-25','加工重量3','商家账号3','商家姓名3'),(64,'2023-06-25 08:17:41','产品编号4','产品名称4','加工企业4','加工工序4','2023-06-25','加工重量4','商家账号4','商家姓名4'),(65,'2023-06-25 08:17:41','产品编号5','产品名称5','加工企业5','加工工序5','2023-06-25','加工重量5','商家账号5','商家姓名5'),(66,'2023-06-25 08:17:41','产品编号6','产品名称6','加工企业6','加工工序6','2023-06-25','加工重量6','商家账号6','商家姓名6'),(67,'2023-06-25 08:17:41','产品编号7','产品名称7','加工企业7','加工工序7','2023-06-25','加工重量7','商家账号7','商家姓名7'),(68,'2023-06-25 08:17:41','产品编号8','产品名称8','加工企业8','加工工序8','2023-06-25','加工重量8','商家账号8','商家姓名8');
/*!40000 ALTER TABLE `jiagongxinxi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shangjia`
--

DROP TABLE IF EXISTS `shangjia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shangjia` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `shangjiazhanghao` varchar(200) NOT NULL COMMENT '商家账号',
  `mima` varchar(200) NOT NULL COMMENT '密码',
  `shangjiaxingming` varchar(200) NOT NULL COMMENT '商家姓名',
  `xingbie` varchar(200) DEFAULT NULL COMMENT '性别',
  `dianhua` varchar(200) DEFAULT NULL COMMENT '电话',
  `touxiang` longtext COMMENT '头像',
  PRIMARY KEY (`id`),
  UNIQUE KEY `shangjiazhanghao` (`shangjiazhanghao`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COMMENT='商家';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shangjia`
--

LOCK TABLES `shangjia` WRITE;
/*!40000 ALTER TABLE `shangjia` DISABLE KEYS */;
INSERT INTO `shangjia` VALUES (21,'2023-06-25 08:17:41','商家账号1','123456','商家姓名1','男','13823888881','upload/shangjia_touxiang1.jpg'),(22,'2023-06-25 08:17:41','商家账号2','123456','商家姓名2','男','13823888882','upload/shangjia_touxiang2.jpg'),(23,'2023-06-25 08:17:41','商家账号3','123456','商家姓名3','男','13823888883','upload/shangjia_touxiang3.jpg'),(24,'2023-06-25 08:17:41','商家账号4','123456','商家姓名4','男','13823888884','upload/shangjia_touxiang4.jpg'),(25,'2023-06-25 08:17:41','商家账号5','123456','商家姓名5','男','13823888885','upload/shangjia_touxiang5.jpg'),(26,'2023-06-25 08:17:41','商家账号6','123456','商家姓名6','男','13823888886','upload/shangjia_touxiang6.jpg'),(27,'2023-06-25 08:17:41','商家账号7','123456','商家姓名7','男','13823888887','upload/shangjia_touxiang7.jpg'),(28,'2023-06-25 08:17:41','商家账号8','123456','商家姓名8','男','13823888888','upload/shangjia_touxiang8.jpg');
/*!40000 ALTER TABLE `shangjia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shifeixinxi`
--

DROP TABLE IF EXISTS `shifeixinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shifeixinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `chanpinbianhao` varchar(200) DEFAULT NULL COMMENT '产品编号',
  `chanpinmingcheng` varchar(200) DEFAULT NULL COMMENT '产品名称',
  `shengzhangzhouqi` varchar(200) DEFAULT NULL COMMENT '生长周期',
  `feiliaomingcheng` varchar(200) DEFAULT NULL COMMENT '肥料名称',
  `shifeimianji` varchar(200) DEFAULT NULL COMMENT '施肥面积',
  `shifeishijian` date DEFAULT NULL COMMENT '施肥时间',
  `shangjiazhanghao` varchar(200) DEFAULT NULL COMMENT '商家账号',
  `shangjiaxingming` varchar(200) DEFAULT NULL COMMENT '商家姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COMMENT='施肥信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shifeixinxi`
--

LOCK TABLES `shifeixinxi` WRITE;
/*!40000 ALTER TABLE `shifeixinxi` DISABLE KEYS */;
INSERT INTO `shifeixinxi` VALUES (41,'2023-06-25 08:17:41','产品编号1','产品名称1','生长周期1','肥料名称1','施肥面积1','2023-06-25','商家账号1','商家姓名1'),(42,'2023-06-25 08:17:41','产品编号2','产品名称2','生长周期2','肥料名称2','施肥面积2','2023-06-25','商家账号2','商家姓名2'),(43,'2023-06-25 08:17:41','产品编号3','产品名称3','生长周期3','肥料名称3','施肥面积3','2023-06-25','商家账号3','商家姓名3'),(44,'2023-06-25 08:17:41','产品编号4','产品名称4','生长周期4','肥料名称4','施肥面积4','2023-06-25','商家账号4','商家姓名4'),(45,'2023-06-25 08:17:41','产品编号5','产品名称5','生长周期5','肥料名称5','施肥面积5','2023-06-25','商家账号5','商家姓名5'),(46,'2023-06-25 08:17:41','产品编号6','产品名称6','生长周期6','肥料名称6','施肥面积6','2023-06-25','商家账号6','商家姓名6'),(47,'2023-06-25 08:17:41','产品编号7','产品名称7','生长周期7','肥料名称7','施肥面积7','2023-06-25','商家账号7','商家姓名7'),(48,'2023-06-25 08:17:41','产品编号8','产品名称8','生长周期8','肥料名称8','施肥面积8','2023-06-25','商家账号8','商家姓名8');
/*!40000 ALTER TABLE `shifeixinxi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shougexinxi`
--

DROP TABLE IF EXISTS `shougexinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shougexinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `chanpinbianhao` varchar(200) DEFAULT NULL COMMENT '产品编号',
  `chanpinmingcheng` varchar(200) DEFAULT NULL COMMENT '产品名称',
  `shougeshijian` datetime DEFAULT NULL COMMENT '收割时间',
  `shougerenyuan` varchar(200) DEFAULT NULL COMMENT '收割人员',
  `shougemianji` varchar(200) DEFAULT NULL COMMENT '收割面积',
  `shougezhongliang` varchar(200) DEFAULT NULL COMMENT '收割重量',
  `shangjiazhanghao` varchar(200) DEFAULT NULL COMMENT '商家账号',
  `shangjiaxingming` varchar(200) DEFAULT NULL COMMENT '商家姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8 COMMENT='收割信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shougexinxi`
--

LOCK TABLES `shougexinxi` WRITE;
/*!40000 ALTER TABLE `shougexinxi` DISABLE KEYS */;
INSERT INTO `shougexinxi` VALUES (51,'2023-06-25 08:17:41','产品编号1','产品名称1','2023-06-25 16:17:41','收割人员1','收割面积1','收割重量1','商家账号1','商家姓名1'),(52,'2023-06-25 08:17:41','产品编号2','产品名称2','2023-06-25 16:17:41','收割人员2','收割面积2','收割重量2','商家账号2','商家姓名2'),(53,'2023-06-25 08:17:41','产品编号3','产品名称3','2023-06-25 16:17:41','收割人员3','收割面积3','收割重量3','商家账号3','商家姓名3'),(54,'2023-06-25 08:17:41','产品编号4','产品名称4','2023-06-25 16:17:41','收割人员4','收割面积4','收割重量4','商家账号4','商家姓名4'),(55,'2023-06-25 08:17:41','产品编号5','产品名称5','2023-06-25 16:17:41','收割人员5','收割面积5','收割重量5','商家账号5','商家姓名5'),(56,'2023-06-25 08:17:41','产品编号6','产品名称6','2023-06-25 16:17:41','收割人员6','收割面积6','收割重量6','商家账号6','商家姓名6'),(57,'2023-06-25 08:17:41','产品编号7','产品名称7','2023-06-25 16:17:41','收割人员7','收割面积7','收割重量7','商家账号7','商家姓名7'),(58,'2023-06-25 08:17:41','产品编号8','产品名称8','2023-06-25 16:17:41','收割人员8','收割面积8','收割重量8','商家账号8','商家姓名8');
/*!40000 ALTER TABLE `shougexinxi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token`
--

DROP TABLE IF EXISTS `token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `token` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `userid` bigint(20) NOT NULL COMMENT '用户id',
  `username` varchar(100) NOT NULL COMMENT '用户名',
  `tablename` varchar(100) DEFAULT NULL COMMENT '表名',
  `role` varchar(100) DEFAULT NULL COMMENT '角色',
  `token` varchar(200) NOT NULL COMMENT '密码',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '新增时间',
  `expiratedtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '过期时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='token表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token`
--

LOCK TABLES `token` WRITE;
/*!40000 ALTER TABLE `token` DISABLE KEYS */;
/*!40000 ALTER TABLE `token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username` varchar(100) NOT NULL COMMENT '用户名',
  `password` varchar(100) NOT NULL COMMENT '密码',
  `role` varchar(100) DEFAULT '管理员' COMMENT '角色',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '新增时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin','管理员','2023-06-25 08:17:42');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xiaoshouxinxi`
--

DROP TABLE IF EXISTS `xiaoshouxinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xiaoshouxinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `chanpinbianhao` varchar(200) DEFAULT NULL COMMENT '产品编号',
  `chanpinmingcheng` varchar(200) DEFAULT NULL COMMENT '产品名称',
  `guige` varchar(200) DEFAULT NULL COMMENT '规格',
  `shuliang` int(11) DEFAULT NULL COMMENT '数量',
  `danjia` int(11) DEFAULT NULL COMMENT '单价',
  `shangjiariqi` datetime DEFAULT NULL COMMENT '上架日期',
  `baozhiqi` varchar(200) DEFAULT NULL COMMENT '保质期',
  `shangjiazhanghao` varchar(200) DEFAULT NULL COMMENT '商家账号',
  `shangjiaxingming` varchar(200) DEFAULT NULL COMMENT '商家姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8 COMMENT='销售信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xiaoshouxinxi`
--

LOCK TABLES `xiaoshouxinxi` WRITE;
/*!40000 ALTER TABLE `xiaoshouxinxi` DISABLE KEYS */;
INSERT INTO `xiaoshouxinxi` VALUES (81,'2023-06-25 08:17:42','产品编号1','产品名称1','规格1',1,1,'2023-06-25 16:17:42','保质期1','商家账号1','商家姓名1'),(82,'2023-06-25 08:17:42','产品编号2','产品名称2','规格2',2,2,'2023-06-25 16:17:42','保质期2','商家账号2','商家姓名2'),(83,'2023-06-25 08:17:42','产品编号3','产品名称3','规格3',3,3,'2023-06-25 16:17:42','保质期3','商家账号3','商家姓名3'),(84,'2023-06-25 08:17:42','产品编号4','产品名称4','规格4',4,4,'2023-06-25 16:17:42','保质期4','商家账号4','商家姓名4'),(85,'2023-06-25 08:17:42','产品编号5','产品名称5','规格5',5,5,'2023-06-25 16:17:42','保质期5','商家账号5','商家姓名5'),(86,'2023-06-25 08:17:42','产品编号6','产品名称6','规格6',6,6,'2023-06-25 16:17:42','保质期6','商家账号6','商家姓名6'),(87,'2023-06-25 08:17:42','产品编号7','产品名称7','规格7',7,7,'2023-06-25 16:17:42','保质期7','商家账号7','商家姓名7'),(88,'2023-06-25 08:17:42','产品编号8','产品名称8','规格8',8,8,'2023-06-25 16:17:42','保质期8','商家账号8','商家姓名8');
/*!40000 ALTER TABLE `xiaoshouxinxi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yonghu`
--

DROP TABLE IF EXISTS `yonghu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yonghu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `zhanghao` varchar(200) NOT NULL COMMENT '账号',
  `mima` varchar(200) NOT NULL COMMENT '密码',
  `xingming` varchar(200) NOT NULL COMMENT '姓名',
  `xingbie` varchar(200) DEFAULT NULL COMMENT '性别',
  `dianhua` varchar(200) DEFAULT NULL COMMENT '电话',
  `touxiang` longtext COMMENT '头像',
  PRIMARY KEY (`id`),
  UNIQUE KEY `zhanghao` (`zhanghao`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COMMENT='用户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yonghu`
--

LOCK TABLES `yonghu` WRITE;
/*!40000 ALTER TABLE `yonghu` DISABLE KEYS */;
INSERT INTO `yonghu` VALUES (11,'2023-06-25 08:17:41','账号1','123456','姓名1','男','13823888881','upload/yonghu_touxiang1.jpg'),(12,'2023-06-25 08:17:41','账号2','123456','姓名2','男','13823888882','upload/yonghu_touxiang2.jpg'),(13,'2023-06-25 08:17:41','账号3','123456','姓名3','男','13823888883','upload/yonghu_touxiang3.jpg'),(14,'2023-06-25 08:17:41','账号4','123456','姓名4','男','13823888884','upload/yonghu_touxiang4.jpg'),(15,'2023-06-25 08:17:41','账号5','123456','姓名5','男','13823888885','upload/yonghu_touxiang5.jpg'),(16,'2023-06-25 08:17:41','账号6','123456','姓名6','男','13823888886','upload/yonghu_touxiang6.jpg'),(17,'2023-06-25 08:17:41','账号7','123456','姓名7','男','13823888887','upload/yonghu_touxiang7.jpg'),(18,'2023-06-25 08:17:41','账号8','123456','姓名8','男','13823888888','upload/yonghu_touxiang8.jpg');
/*!40000 ALTER TABLE `yonghu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yunshuxinxi`
--

DROP TABLE IF EXISTS `yunshuxinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yunshuxinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `chanpinbianhao` varchar(200) DEFAULT NULL COMMENT '产品编号',
  `chanpinmingcheng` varchar(200) DEFAULT NULL COMMENT '产品名称',
  `chanpinzhongliang` varchar(200) DEFAULT NULL COMMENT '产品重量',
  `wuliugongsi` varchar(200) DEFAULT NULL COMMENT '物流公司',
  `fahuodidian` varchar(200) DEFAULT NULL COMMENT '发货地点',
  `yunsongdidian` varchar(200) DEFAULT NULL COMMENT '运送地点',
  `yunshushijian` datetime DEFAULT NULL COMMENT '运输时间',
  `daodashijian` datetime DEFAULT NULL COMMENT '到达时间',
  `shangjiazhanghao` varchar(200) DEFAULT NULL COMMENT '商家账号',
  `shangjiaxingming` varchar(200) DEFAULT NULL COMMENT '商家姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8 COMMENT='运输信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yunshuxinxi`
--

LOCK TABLES `yunshuxinxi` WRITE;
/*!40000 ALTER TABLE `yunshuxinxi` DISABLE KEYS */;
INSERT INTO `yunshuxinxi` VALUES (71,'2023-06-25 08:17:42','产品编号1','产品名称1','产品重量1','物流公司1','发货地点1','运送地点1','2023-06-25 16:17:42','2023-06-25 16:17:42','商家账号1','商家姓名1'),(72,'2023-06-25 08:17:42','产品编号2','产品名称2','产品重量2','物流公司2','发货地点2','运送地点2','2023-06-25 16:17:42','2023-06-25 16:17:42','商家账号2','商家姓名2'),(73,'2023-06-25 08:17:42','产品编号3','产品名称3','产品重量3','物流公司3','发货地点3','运送地点3','2023-06-25 16:17:42','2023-06-25 16:17:42','商家账号3','商家姓名3'),(74,'2023-06-25 08:17:42','产品编号4','产品名称4','产品重量4','物流公司4','发货地点4','运送地点4','2023-06-25 16:17:42','2023-06-25 16:17:42','商家账号4','商家姓名4'),(75,'2023-06-25 08:17:42','产品编号5','产品名称5','产品重量5','物流公司5','发货地点5','运送地点5','2023-06-25 16:17:42','2023-06-25 16:17:42','商家账号5','商家姓名5'),(76,'2023-06-25 08:17:42','产品编号6','产品名称6','产品重量6','物流公司6','发货地点6','运送地点6','2023-06-25 16:17:42','2023-06-25 16:17:42','商家账号6','商家姓名6'),(77,'2023-06-25 08:17:42','产品编号7','产品名称7','产品重量7','物流公司7','发货地点7','运送地点7','2023-06-25 16:17:42','2023-06-25 16:17:42','商家账号7','商家姓名7'),(78,'2023-06-25 08:17:42','产品编号8','产品名称8','产品重量8','物流公司8','发货地点8','运送地点8','2023-06-25 16:17:42','2023-06-25 16:17:42','商家账号8','商家姓名8');
/*!40000 ALTER TABLE `yunshuxinxi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zhongzhixinxi`
--

DROP TABLE IF EXISTS `zhongzhixinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zhongzhixinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `chanpinbianhao` varchar(200) DEFAULT NULL COMMENT '产品编号',
  `chanpinmingcheng` varchar(200) DEFAULT NULL COMMENT '产品名称',
  `zhongzhinonghu` varchar(200) DEFAULT NULL COMMENT '种植农户',
  `zhongzhishijian` varchar(200) DEFAULT NULL COMMENT '种植时间',
  `zhongzhididian` varchar(200) DEFAULT NULL COMMENT '种植地点',
  `zhongzhimianji` varchar(200) DEFAULT NULL COMMENT '种植面积',
  `shangjiazhanghao` varchar(200) DEFAULT NULL COMMENT '商家账号',
  `shangjiaxingming` varchar(200) DEFAULT NULL COMMENT '商家姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COMMENT='种植信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zhongzhixinxi`
--

LOCK TABLES `zhongzhixinxi` WRITE;
/*!40000 ALTER TABLE `zhongzhixinxi` DISABLE KEYS */;
INSERT INTO `zhongzhixinxi` VALUES (31,'2023-06-25 08:17:41','产品编号1','产品名称1','种植农户1','种植时间1','种植地点1','种植面积1','商家账号1','商家姓名1'),(32,'2023-06-25 08:17:41','产品编号2','产品名称2','种植农户2','种植时间2','种植地点2','种植面积2','商家账号2','商家姓名2'),(33,'2023-06-25 08:17:41','产品编号3','产品名称3','种植农户3','种植时间3','种植地点3','种植面积3','商家账号3','商家姓名3'),(34,'2023-06-25 08:17:41','产品编号4','产品名称4','种植农户4','种植时间4','种植地点4','种植面积4','商家账号4','商家姓名4'),(35,'2023-06-25 08:17:41','产品编号5','产品名称5','种植农户5','种植时间5','种植地点5','种植面积5','商家账号5','商家姓名5'),(36,'2023-06-25 08:17:41','产品编号6','产品名称6','种植农户6','种植时间6','种植地点6','种植面积6','商家账号6','商家姓名6'),(37,'2023-06-25 08:17:41','产品编号7','产品名称7','种植农户7','种植时间7','种植地点7','种植面积7','商家账号7','商家姓名7'),(38,'2023-06-25 08:17:41','产品编号8','产品名称8','种植农户8','种植时间8','种植地点8','种植面积8','商家账号8','商家姓名8');
/*!40000 ALTER TABLE `zhongzhixinxi` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-25 16:22:32
