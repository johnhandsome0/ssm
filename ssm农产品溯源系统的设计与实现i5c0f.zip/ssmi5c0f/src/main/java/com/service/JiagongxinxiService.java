package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.JiagongxinxiEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.JiagongxinxiVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.JiagongxinxiView;


/**
 * 加工信息
 *
 * @author 
 * @email 
 * @date 2023-06-25 16:17:23
 */
public interface JiagongxinxiService extends IService<JiagongxinxiEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<JiagongxinxiVO> selectListVO(Wrapper<JiagongxinxiEntity> wrapper);
   	
   	JiagongxinxiVO selectVO(@Param("ew") Wrapper<JiagongxinxiEntity> wrapper);
   	
   	List<JiagongxinxiView> selectListView(Wrapper<JiagongxinxiEntity> wrapper);
   	
   	JiagongxinxiView selectView(@Param("ew") Wrapper<JiagongxinxiEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<JiagongxinxiEntity> wrapper);
   	

}

