package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.ShifeixinxiDao;
import com.entity.ShifeixinxiEntity;
import com.service.ShifeixinxiService;
import com.entity.vo.ShifeixinxiVO;
import com.entity.view.ShifeixinxiView;

@Service("shifeixinxiService")
public class ShifeixinxiServiceImpl extends ServiceImpl<ShifeixinxiDao, ShifeixinxiEntity> implements ShifeixinxiService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<ShifeixinxiEntity> page = this.selectPage(
                new Query<ShifeixinxiEntity>(params).getPage(),
                new EntityWrapper<ShifeixinxiEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<ShifeixinxiEntity> wrapper) {
		  Page<ShifeixinxiView> page =new Query<ShifeixinxiView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<ShifeixinxiVO> selectListVO(Wrapper<ShifeixinxiEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public ShifeixinxiVO selectVO(Wrapper<ShifeixinxiEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<ShifeixinxiView> selectListView(Wrapper<ShifeixinxiEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public ShifeixinxiView selectView(Wrapper<ShifeixinxiEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
