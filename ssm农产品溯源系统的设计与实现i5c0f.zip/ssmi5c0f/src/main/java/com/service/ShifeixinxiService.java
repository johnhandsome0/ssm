package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.ShifeixinxiEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.ShifeixinxiVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.ShifeixinxiView;


/**
 * 施肥信息
 *
 * @author 
 * @email 
 * @date 2023-06-25 16:17:23
 */
public interface ShifeixinxiService extends IService<ShifeixinxiEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<ShifeixinxiVO> selectListVO(Wrapper<ShifeixinxiEntity> wrapper);
   	
   	ShifeixinxiVO selectVO(@Param("ew") Wrapper<ShifeixinxiEntity> wrapper);
   	
   	List<ShifeixinxiView> selectListView(Wrapper<ShifeixinxiEntity> wrapper);
   	
   	ShifeixinxiView selectView(@Param("ew") Wrapper<ShifeixinxiEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<ShifeixinxiEntity> wrapper);
   	

}

