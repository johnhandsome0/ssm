package com.dao;

import com.entity.XiaoshouxinxiEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.XiaoshouxinxiVO;
import com.entity.view.XiaoshouxinxiView;


/**
 * 销售信息
 * 
 * @author 
 * @email 
 * @date 2023-06-25 16:17:23
 */
public interface XiaoshouxinxiDao extends BaseMapper<XiaoshouxinxiEntity> {
	
	List<XiaoshouxinxiVO> selectListVO(@Param("ew") Wrapper<XiaoshouxinxiEntity> wrapper);
	
	XiaoshouxinxiVO selectVO(@Param("ew") Wrapper<XiaoshouxinxiEntity> wrapper);
	
	List<XiaoshouxinxiView> selectListView(@Param("ew") Wrapper<XiaoshouxinxiEntity> wrapper);

	List<XiaoshouxinxiView> selectListView(Pagination page,@Param("ew") Wrapper<XiaoshouxinxiEntity> wrapper);
	
	XiaoshouxinxiView selectView(@Param("ew") Wrapper<XiaoshouxinxiEntity> wrapper);
	

}
