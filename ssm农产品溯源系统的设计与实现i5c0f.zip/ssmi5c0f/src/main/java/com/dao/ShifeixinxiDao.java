package com.dao;

import com.entity.ShifeixinxiEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.ShifeixinxiVO;
import com.entity.view.ShifeixinxiView;


/**
 * 施肥信息
 * 
 * @author 
 * @email 
 * @date 2023-06-25 16:17:23
 */
public interface ShifeixinxiDao extends BaseMapper<ShifeixinxiEntity> {
	
	List<ShifeixinxiVO> selectListVO(@Param("ew") Wrapper<ShifeixinxiEntity> wrapper);
	
	ShifeixinxiVO selectVO(@Param("ew") Wrapper<ShifeixinxiEntity> wrapper);
	
	List<ShifeixinxiView> selectListView(@Param("ew") Wrapper<ShifeixinxiEntity> wrapper);

	List<ShifeixinxiView> selectListView(Pagination page,@Param("ew") Wrapper<ShifeixinxiEntity> wrapper);
	
	ShifeixinxiView selectView(@Param("ew") Wrapper<ShifeixinxiEntity> wrapper);
	

}
