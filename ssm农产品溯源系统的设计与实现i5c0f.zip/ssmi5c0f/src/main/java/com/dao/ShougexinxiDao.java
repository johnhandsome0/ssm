package com.dao;

import com.entity.ShougexinxiEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.ShougexinxiVO;
import com.entity.view.ShougexinxiView;


/**
 * 收割信息
 * 
 * @author 
 * @email 
 * @date 2023-06-25 16:17:23
 */
public interface ShougexinxiDao extends BaseMapper<ShougexinxiEntity> {
	
	List<ShougexinxiVO> selectListVO(@Param("ew") Wrapper<ShougexinxiEntity> wrapper);
	
	ShougexinxiVO selectVO(@Param("ew") Wrapper<ShougexinxiEntity> wrapper);
	
	List<ShougexinxiView> selectListView(@Param("ew") Wrapper<ShougexinxiEntity> wrapper);

	List<ShougexinxiView> selectListView(Pagination page,@Param("ew") Wrapper<ShougexinxiEntity> wrapper);
	
	ShougexinxiView selectView(@Param("ew") Wrapper<ShougexinxiEntity> wrapper);
	

}
