package com.dao;

import com.entity.JiagongxinxiEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.JiagongxinxiVO;
import com.entity.view.JiagongxinxiView;


/**
 * 加工信息
 * 
 * @author 
 * @email 
 * @date 2023-06-25 16:17:23
 */
public interface JiagongxinxiDao extends BaseMapper<JiagongxinxiEntity> {
	
	List<JiagongxinxiVO> selectListVO(@Param("ew") Wrapper<JiagongxinxiEntity> wrapper);
	
	JiagongxinxiVO selectVO(@Param("ew") Wrapper<JiagongxinxiEntity> wrapper);
	
	List<JiagongxinxiView> selectListView(@Param("ew") Wrapper<JiagongxinxiEntity> wrapper);

	List<JiagongxinxiView> selectListView(Pagination page,@Param("ew") Wrapper<JiagongxinxiEntity> wrapper);
	
	JiagongxinxiView selectView(@Param("ew") Wrapper<JiagongxinxiEntity> wrapper);
	

}
