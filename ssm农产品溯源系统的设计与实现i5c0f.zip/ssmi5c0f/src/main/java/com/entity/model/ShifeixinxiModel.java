package com.entity.model;

import com.entity.ShifeixinxiEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import java.io.Serializable;
 

/**
 * 施肥信息
 * 接收传参的实体类  
 *（实际开发中配合移动端接口开发手动去掉些没用的字段， 后端一般用entity就够用了） 
 * 取自ModelAndView 的model名称
 * @author 
 * @email 
 * @date 2023-06-25 16:17:23
 */
public class ShifeixinxiModel  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 产品名称
	 */
	
	private String chanpinmingcheng;
		
	/**
	 * 生长周期
	 */
	
	private String shengzhangzhouqi;
		
	/**
	 * 肥料名称
	 */
	
	private String feiliaomingcheng;
		
	/**
	 * 施肥面积
	 */
	
	private String shifeimianji;
		
	/**
	 * 施肥时间
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date shifeishijian;
		
	/**
	 * 商家账号
	 */
	
	private String shangjiazhanghao;
		
	/**
	 * 商家姓名
	 */
	
	private String shangjiaxingming;
				
	
	/**
	 * 设置：产品名称
	 */
	 
	public void setChanpinmingcheng(String chanpinmingcheng) {
		this.chanpinmingcheng = chanpinmingcheng;
	}
	
	/**
	 * 获取：产品名称
	 */
	public String getChanpinmingcheng() {
		return chanpinmingcheng;
	}
				
	
	/**
	 * 设置：生长周期
	 */
	 
	public void setShengzhangzhouqi(String shengzhangzhouqi) {
		this.shengzhangzhouqi = shengzhangzhouqi;
	}
	
	/**
	 * 获取：生长周期
	 */
	public String getShengzhangzhouqi() {
		return shengzhangzhouqi;
	}
				
	
	/**
	 * 设置：肥料名称
	 */
	 
	public void setFeiliaomingcheng(String feiliaomingcheng) {
		this.feiliaomingcheng = feiliaomingcheng;
	}
	
	/**
	 * 获取：肥料名称
	 */
	public String getFeiliaomingcheng() {
		return feiliaomingcheng;
	}
				
	
	/**
	 * 设置：施肥面积
	 */
	 
	public void setShifeimianji(String shifeimianji) {
		this.shifeimianji = shifeimianji;
	}
	
	/**
	 * 获取：施肥面积
	 */
	public String getShifeimianji() {
		return shifeimianji;
	}
				
	
	/**
	 * 设置：施肥时间
	 */
	 
	public void setShifeishijian(Date shifeishijian) {
		this.shifeishijian = shifeishijian;
	}
	
	/**
	 * 获取：施肥时间
	 */
	public Date getShifeishijian() {
		return shifeishijian;
	}
				
	
	/**
	 * 设置：商家账号
	 */
	 
	public void setShangjiazhanghao(String shangjiazhanghao) {
		this.shangjiazhanghao = shangjiazhanghao;
	}
	
	/**
	 * 获取：商家账号
	 */
	public String getShangjiazhanghao() {
		return shangjiazhanghao;
	}
				
	
	/**
	 * 设置：商家姓名
	 */
	 
	public void setShangjiaxingming(String shangjiaxingming) {
		this.shangjiaxingming = shangjiaxingming;
	}
	
	/**
	 * 获取：商家姓名
	 */
	public String getShangjiaxingming() {
		return shangjiaxingming;
	}
			
}
