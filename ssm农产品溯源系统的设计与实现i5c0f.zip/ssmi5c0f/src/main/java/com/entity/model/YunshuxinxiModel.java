package com.entity.model;

import com.entity.YunshuxinxiEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import java.io.Serializable;
 

/**
 * 运输信息
 * 接收传参的实体类  
 *（实际开发中配合移动端接口开发手动去掉些没用的字段， 后端一般用entity就够用了） 
 * 取自ModelAndView 的model名称
 * @author 
 * @email 
 * @date 2023-06-25 16:17:23
 */
public class YunshuxinxiModel  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 产品名称
	 */
	
	private String chanpinmingcheng;
		
	/**
	 * 产品重量
	 */
	
	private String chanpinzhongliang;
		
	/**
	 * 物流公司
	 */
	
	private String wuliugongsi;
		
	/**
	 * 发货地点
	 */
	
	private String fahuodidian;
		
	/**
	 * 运送地点
	 */
	
	private String yunsongdidian;
		
	/**
	 * 运输时间
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date yunshushijian;
		
	/**
	 * 到达时间
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date daodashijian;
		
	/**
	 * 商家账号
	 */
	
	private String shangjiazhanghao;
		
	/**
	 * 商家姓名
	 */
	
	private String shangjiaxingming;
				
	
	/**
	 * 设置：产品名称
	 */
	 
	public void setChanpinmingcheng(String chanpinmingcheng) {
		this.chanpinmingcheng = chanpinmingcheng;
	}
	
	/**
	 * 获取：产品名称
	 */
	public String getChanpinmingcheng() {
		return chanpinmingcheng;
	}
				
	
	/**
	 * 设置：产品重量
	 */
	 
	public void setChanpinzhongliang(String chanpinzhongliang) {
		this.chanpinzhongliang = chanpinzhongliang;
	}
	
	/**
	 * 获取：产品重量
	 */
	public String getChanpinzhongliang() {
		return chanpinzhongliang;
	}
				
	
	/**
	 * 设置：物流公司
	 */
	 
	public void setWuliugongsi(String wuliugongsi) {
		this.wuliugongsi = wuliugongsi;
	}
	
	/**
	 * 获取：物流公司
	 */
	public String getWuliugongsi() {
		return wuliugongsi;
	}
				
	
	/**
	 * 设置：发货地点
	 */
	 
	public void setFahuodidian(String fahuodidian) {
		this.fahuodidian = fahuodidian;
	}
	
	/**
	 * 获取：发货地点
	 */
	public String getFahuodidian() {
		return fahuodidian;
	}
				
	
	/**
	 * 设置：运送地点
	 */
	 
	public void setYunsongdidian(String yunsongdidian) {
		this.yunsongdidian = yunsongdidian;
	}
	
	/**
	 * 获取：运送地点
	 */
	public String getYunsongdidian() {
		return yunsongdidian;
	}
				
	
	/**
	 * 设置：运输时间
	 */
	 
	public void setYunshushijian(Date yunshushijian) {
		this.yunshushijian = yunshushijian;
	}
	
	/**
	 * 获取：运输时间
	 */
	public Date getYunshushijian() {
		return yunshushijian;
	}
				
	
	/**
	 * 设置：到达时间
	 */
	 
	public void setDaodashijian(Date daodashijian) {
		this.daodashijian = daodashijian;
	}
	
	/**
	 * 获取：到达时间
	 */
	public Date getDaodashijian() {
		return daodashijian;
	}
				
	
	/**
	 * 设置：商家账号
	 */
	 
	public void setShangjiazhanghao(String shangjiazhanghao) {
		this.shangjiazhanghao = shangjiazhanghao;
	}
	
	/**
	 * 获取：商家账号
	 */
	public String getShangjiazhanghao() {
		return shangjiazhanghao;
	}
				
	
	/**
	 * 设置：商家姓名
	 */
	 
	public void setShangjiaxingming(String shangjiaxingming) {
		this.shangjiaxingming = shangjiaxingming;
	}
	
	/**
	 * 获取：商家姓名
	 */
	public String getShangjiaxingming() {
		return shangjiaxingming;
	}
			
}
