package com.entity.vo;

import com.entity.JiagongxinxiEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
 

/**
 * 加工信息
 * 手机端接口返回实体辅助类 
 * （主要作用去除一些不必要的字段）
 * @author 
 * @email 
 * @date 2023-06-25 16:17:23
 */
public class JiagongxinxiVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 产品名称
	 */
	
	private String chanpinmingcheng;
		
	/**
	 * 加工企业
	 */
	
	private String jiagongqiye;
		
	/**
	 * 加工工序
	 */
	
	private String jiagonggongxu;
		
	/**
	 * 加工时间
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date jiagongshijian;
		
	/**
	 * 加工重量
	 */
	
	private String jiagongzhongliang;
		
	/**
	 * 商家账号
	 */
	
	private String shangjiazhanghao;
		
	/**
	 * 商家姓名
	 */
	
	private String shangjiaxingming;
				
	
	/**
	 * 设置：产品名称
	 */
	 
	public void setChanpinmingcheng(String chanpinmingcheng) {
		this.chanpinmingcheng = chanpinmingcheng;
	}
	
	/**
	 * 获取：产品名称
	 */
	public String getChanpinmingcheng() {
		return chanpinmingcheng;
	}
				
	
	/**
	 * 设置：加工企业
	 */
	 
	public void setJiagongqiye(String jiagongqiye) {
		this.jiagongqiye = jiagongqiye;
	}
	
	/**
	 * 获取：加工企业
	 */
	public String getJiagongqiye() {
		return jiagongqiye;
	}
				
	
	/**
	 * 设置：加工工序
	 */
	 
	public void setJiagonggongxu(String jiagonggongxu) {
		this.jiagonggongxu = jiagonggongxu;
	}
	
	/**
	 * 获取：加工工序
	 */
	public String getJiagonggongxu() {
		return jiagonggongxu;
	}
				
	
	/**
	 * 设置：加工时间
	 */
	 
	public void setJiagongshijian(Date jiagongshijian) {
		this.jiagongshijian = jiagongshijian;
	}
	
	/**
	 * 获取：加工时间
	 */
	public Date getJiagongshijian() {
		return jiagongshijian;
	}
				
	
	/**
	 * 设置：加工重量
	 */
	 
	public void setJiagongzhongliang(String jiagongzhongliang) {
		this.jiagongzhongliang = jiagongzhongliang;
	}
	
	/**
	 * 获取：加工重量
	 */
	public String getJiagongzhongliang() {
		return jiagongzhongliang;
	}
				
	
	/**
	 * 设置：商家账号
	 */
	 
	public void setShangjiazhanghao(String shangjiazhanghao) {
		this.shangjiazhanghao = shangjiazhanghao;
	}
	
	/**
	 * 获取：商家账号
	 */
	public String getShangjiazhanghao() {
		return shangjiazhanghao;
	}
				
	
	/**
	 * 设置：商家姓名
	 */
	 
	public void setShangjiaxingming(String shangjiaxingming) {
		this.shangjiaxingming = shangjiaxingming;
	}
	
	/**
	 * 获取：商家姓名
	 */
	public String getShangjiaxingming() {
		return shangjiaxingming;
	}
			
}
