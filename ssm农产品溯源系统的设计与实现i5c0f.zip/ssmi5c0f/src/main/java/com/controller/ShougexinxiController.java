package com.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

import com.utils.ValidatorUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.annotation.IgnoreAuth;

import com.entity.ShougexinxiEntity;
import com.entity.view.ShougexinxiView;

import com.service.ShougexinxiService;
import com.service.TokenService;
import com.utils.PageUtils;
import com.utils.R;
import com.utils.MD5Util;
import com.utils.MPUtil;
import com.utils.CommonUtil;

/**
 * 收割信息
 * 后端接口
 * @author 
 * @email 
 * @date 2023-06-25 16:17:23
 */
@RestController
@RequestMapping("/shougexinxi")
public class ShougexinxiController {
    @Autowired
    private ShougexinxiService shougexinxiService;




    


    /**
     * 后端列表
     */
    @RequestMapping("/page")
    public R page(@RequestParam Map<String, Object> params,ShougexinxiEntity shougexinxi, 
		HttpServletRequest request){

		String tableName = request.getSession().getAttribute("tableName").toString();
		if(tableName.equals("shangjia")) {
			shougexinxi.setShangjiazhanghao((String)request.getSession().getAttribute("username"));
		}
        EntityWrapper<ShougexinxiEntity> ew = new EntityWrapper<ShougexinxiEntity>();


		PageUtils page = shougexinxiService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, shougexinxi), params), params));
        return R.ok().put("data", page);
    }
    
    /**
     * 前端列表
     */
	@IgnoreAuth
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params,ShougexinxiEntity shougexinxi, 
		HttpServletRequest request){
        EntityWrapper<ShougexinxiEntity> ew = new EntityWrapper<ShougexinxiEntity>();

		PageUtils page = shougexinxiService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, shougexinxi), params), params));
        return R.ok().put("data", page);
    }

	/**
     * 列表
     */
    @RequestMapping("/lists")
    public R list( ShougexinxiEntity shougexinxi){
       	EntityWrapper<ShougexinxiEntity> ew = new EntityWrapper<ShougexinxiEntity>();
      	ew.allEq(MPUtil.allEQMapPre( shougexinxi, "shougexinxi")); 
        return R.ok().put("data", shougexinxiService.selectListView(ew));
    }

	 /**
     * 查询
     */
    @RequestMapping("/query")
    public R query(ShougexinxiEntity shougexinxi){
        EntityWrapper< ShougexinxiEntity> ew = new EntityWrapper< ShougexinxiEntity>();
 		ew.allEq(MPUtil.allEQMapPre( shougexinxi, "shougexinxi")); 
		ShougexinxiView shougexinxiView =  shougexinxiService.selectView(ew);
		return R.ok("查询收割信息成功").put("data", shougexinxiView);
    }
	
    /**
     * 后端详情
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Long id){
        ShougexinxiEntity shougexinxi = shougexinxiService.selectById(id);
        return R.ok().put("data", shougexinxi);
    }

    /**
     * 前端详情
     */
	@IgnoreAuth
    @RequestMapping("/detail/{id}")
    public R detail(@PathVariable("id") Long id){
        ShougexinxiEntity shougexinxi = shougexinxiService.selectById(id);
        return R.ok().put("data", shougexinxi);
    }
    



    /**
     * 后端保存
     */
    @RequestMapping("/save")
    public R save(@RequestBody ShougexinxiEntity shougexinxi, HttpServletRequest request){
    	shougexinxi.setId(new Date().getTime()+new Double(Math.floor(Math.random()*1000)).longValue());
    	//ValidatorUtils.validateEntity(shougexinxi);

        shougexinxiService.insert(shougexinxi);
        return R.ok();
    }
    
    /**
     * 前端保存
     */
    @RequestMapping("/add")
    public R add(@RequestBody ShougexinxiEntity shougexinxi, HttpServletRequest request){
    	shougexinxi.setId(new Date().getTime()+new Double(Math.floor(Math.random()*1000)).longValue());
    	//ValidatorUtils.validateEntity(shougexinxi);

        shougexinxiService.insert(shougexinxi);
        return R.ok();
    }


    /**
     * 修改
     */
    @RequestMapping("/update")
    @Transactional
    public R update(@RequestBody ShougexinxiEntity shougexinxi, HttpServletRequest request){
        //ValidatorUtils.validateEntity(shougexinxi);
        shougexinxiService.updateById(shougexinxi);//全部更新
        return R.ok();
    }

    
    

    /**
     * 删除
     */
    @RequestMapping("/delete")
    public R delete(@RequestBody Long[] ids){
        shougexinxiService.deleteBatchIds(Arrays.asList(ids));
        return R.ok();
    }
    
	









}
